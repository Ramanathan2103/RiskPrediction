package com.example.subashb.androiddiabeticfounderapp;

/**
 * Created by subash.b on 27-Feb-17.
 */

public class Constants {
    public static String EMAILID_FROM = "cbeajtech@gmail.com";
    public static String EMAILID_TO= "cbeajtech@gmail.com";

}
